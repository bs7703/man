/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:41:19 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 08:08:41 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed(int raw)
{
	setRawBits(raw);
}
Fixed::Fixed(float val)
{
	int	n;

	setRawBits((int)val);
	n = (int)roundf(val * 256) & 0xff;
	if (val < 0)
		rawbits -= n;
	else
		rawbits += n;
}
Fixed::Fixed(void)
{
	rawbits = 0;
}
Fixed::Fixed(const Fixed &fix)
{
	rawbits = fix.getRawBits();
}
Fixed::~Fixed(void)
{
}
std::ostream&	operator<<(std::ostream& os, const Fixed &f)
{
	os << f.toFloat();
	return (os);
}
Fixed	&Fixed::operator=(const Fixed &fix)
{
	rawbits = fix.getRawBits();
	return (*this);
}
int				Fixed::getRawBits(void) const
{
	return (rawbits);
}
void		 	Fixed::setRawBits(int const raw)
{
	uint64_t	l;
	int			sign;

	sign = 1;
	l = raw;
	if (raw < 0)
	{
		sign = -1;
		l = (int64_t)raw * -1;
	}
	rawbits = (int)(l << FRACT_SIZE);
	rawbits *= sign;
}
float 	Fixed::toFloat(void) const
{
	float	m;

	if (getRawBits() < 0)
		m = -1 * (int)((uint64_t)(((int64_t)getRawBits() * -1)) >> FRACT_SIZE)
			-  ((float)(getRawBits() & 0xff)) / 256.0f;
	else
		m = (getRawBits()  >> FRACT_SIZE) + ((float)(getRawBits() & 0xff)) / 256.0f;
	return (m);
}
int		Fixed::toInt(void) const
{
	return ((int)roundf(toFloat()));
}
bool	Fixed::operator>(const Fixed &fix)
{
	if (toInt() > fix.toInt())
		return (true);
	return (false);
}
bool	Fixed::operator==(const Fixed &fix)
{
	if (fix.toFloat() == toFloat())
		return (true);
	return (false);
}
bool	Fixed::operator<(const Fixed &fix)
{
	if (fix.toFloat() > toFloat())
		return (false);
	return (true);
}
bool	Fixed::operator<=(const Fixed &fix)
{
	if (toFloat() > fix.toFloat())
		return (false);
	return (true);
}
bool	Fixed::operator>=(const Fixed &fix)
{
	if (fix.toFloat() > toFloat())
		return (false);
	return (true);
}
bool	Fixed::operator!=(const Fixed &fix)
{
	if (fix.toFloat() == toFloat())
		return (false);
	return (true);
}
Fixed	Fixed::operator*(const Fixed &fix)
{
	return (Fixed(fix.toFloat() * toFloat()));
}
Fixed	Fixed::operator-(const Fixed &fix)
{
	return (Fixed(toFloat() - fix.toFloat()));
}
Fixed	Fixed::operator+(const Fixed &fix)
{
	return (Fixed(toFloat() - fix.toFloat()));
}
Fixed	Fixed::operator/(const Fixed &fix)
{
	return (Fixed(toFloat() / fix.toFloat()));
}
Fixed	&Fixed::operator--(void)
{
	rawbits -= 1;
	return (*this);
}
Fixed	Fixed::operator--(int)
{
	Fixed	temp(toFloat());
	rawbits -= 1;
	return (temp);
}
Fixed	&Fixed::operator++(void)
{
	rawbits += 1;
	return (*this);
}
Fixed	Fixed::operator++(int)
{
	Fixed	temp(toFloat());
	rawbits += 1;
	return (temp);
}
const Fixed	&Fixed::min(const Fixed &fix1, const Fixed &fix2)
{
	if (fix2.toFloat() < fix1.toFloat())
		return (fix2);
	return (fix1);
}
const Fixed	&Fixed::max(const Fixed &fix1, const Fixed &fix2)
{
	if (fix1.toFloat() < fix2.toFloat())
		return (fix2);
	return (fix1);
}
