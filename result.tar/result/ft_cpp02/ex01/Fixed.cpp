/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:41:19 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 08:08:56 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed(int raw)
{
	std::cout << "Int constructor called" << std::endl;
	setRawBits(raw);
}
Fixed::Fixed(float val)
{
	int	n;

	std::cout << "Float constructor called" << std::endl;
	setRawBits((int)val);
	n = (int)roundf(val * 256) & 0xff;
	if (val < 0)
		rawbits -= n;
	else
		rawbits += n;
}
Fixed::Fixed(void)
{
	rawbits = 0;
	std::cout << "Default constructor called" << std::endl;
}
Fixed::Fixed(const Fixed &fix)
{
	std::cout << "Copy constructor called" << std::endl;
	*this = fix;
}
Fixed::~Fixed(void)
{
	std::cout << "Destructor called" << std::endl;
}
std::ostream&	operator<<(std::ostream& os, const Fixed &f)
{
	os << f.toFloat();
	return (os);
}
Fixed	&Fixed::operator=(const Fixed &fix)
{
	std::cout << "Assignation operator called" << std::endl;
	rawbits = fix.getRawBits();
	return (*this);
}
int				Fixed::getRawBits(void) const
{
	return (rawbits);
}
void		 	Fixed::setRawBits(int const raw)
{
	uint64_t	l;
	int			sign;

	sign = 1;
	l = raw;
	if (raw < 0)
	{
		sign = -1;
		l = (int64_t)raw * -1;
	}
	rawbits = (int)(l << FRACT_SIZE);
	rawbits *= sign;
}
float 	Fixed::toFloat(void) const
{
	float	m;

	if (getRawBits() < 0)
		m = -1 * (int)((uint64_t)(((int64_t)getRawBits() * -1)) >> FRACT_SIZE)
			-  ((float)(getRawBits() & 0xff)) / 256.0f;
	else
		m = (getRawBits()  >> FRACT_SIZE) + ((float)(getRawBits() & 0xff)) / 256.0f;
	return (m);
}
int		Fixed::toInt(void) const
{
	return ((int)toFloat());
}
