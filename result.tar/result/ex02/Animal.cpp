/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Animal.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:45:58 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:04:14 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Animal.hpp"

Animal::Animal(void): type("animal")
{
	std::cout << "animal made\n";
}
Animal::~Animal(void)
{
	std::cout << "animal died\n";
}
Animal::Animal(const Animal &animal)
{
	type = animal.type;
}
Animal	&Animal::operator=(const Animal &animal)
{
	type = animal.type;
	return (*this);
}
std::string	Animal::getType(void) const
{
	return (type);
}
