/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 06:10:30 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 18:39:59 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef BRAIN_HPP

# define BRAIN_HPP

#include <iostream>

class Brain
{
	public:
	Brain(void);
	Brain(const Brain &brain);
	~Brain(void);
	Brain	&operator=(const Brain &brain);
	private:
	std::string	ideas[100];
};

#endif
