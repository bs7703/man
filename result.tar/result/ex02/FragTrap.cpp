/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:58:13 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 16:30:45 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "FragTrap.hpp"

FragTrap::~FragTrap(void)
{
	std::cout << "FragTrap has died.\n";
}
FragTrap::FragTrap(const FragTrap &s): ClapTrap(s.getName())
{
	*this = s;
}
FragTrap	&FragTrap::operator=(const FragTrap &s)
{
	this->name = s.getName();
	this->hp = s.getHp();
	this->ap = s.getAp();
	this->ep = s.getEp();
	return (*this);
}

FragTrap::FragTrap(std::string n): ClapTrap(n)
{
	this->name = n;
	this->hp = 100;
	this->ap = 30;
	this->ep = 100;
	std::cout << "name:" << getName() << std::endl;
	std::cout << "hp:" << getHp() << std::endl;
	std::cout << "ep:" << getEp() << std::endl;
	std::cout << "ap:" << getAp() << std::endl;
}

void	FragTrap::highFiveGuys(void)
{
	std::cout << "FragTrap has highfived.\n";
}
