/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:13:16 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 14:07:54 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CLAPTRAP_HPP

# define CLAPTRAP_HPP

#include <iostream>

class ClapTrap
{
	public:
	ClapTrap(std::string n);
	ClapTrap(const ClapTrap &c);
	ClapTrap	&operator=(const ClapTrap &c);
	~ClapTrap(void);
	ClapTrap(void);
	void			attack(std::string const & target);
	void			takeDamage(unsigned int	amount);
	void			beRepaired(unsigned int amount);
	unsigned int	getHp(void) const;
	unsigned int	getEp(void) const;
	unsigned int	getAp(void) const;
	std::string		getName(void) const;
	protected:
	unsigned int	hp;
	unsigned int	ep;
	unsigned int	ap;
	std::string		name;
};
#endif
