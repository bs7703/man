/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cat.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:45:58 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 18:48:20 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Cat.hpp"

Cat::Cat(void)
{
	Cat::type = "cat";
	std::cout << "catcat made\n";
	brain = new Brain();
}

Cat::~Cat(void)
{
	std::cout << "catcat died\n";
	delete brain;
}
std::string	Cat::getType(void)
{
	return (type);
}
void	Cat::makeSound(void) const
{
	std::cout << "meowmeow\n";
}
Cat::Cat(const Cat &cat)
{
	std::cout << "catcat made\n";
	*this = cat;
}
Cat	&Cat::operator=(const Cat &cat)
{
	*brain = *(cat.brain);
	return (*this);
}
