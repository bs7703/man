/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Brain.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 06:11:37 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 18:39:52 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Brain.hpp"

Brain::Brain(void)
{
}
Brain::Brain(const Brain &brain)
{
	*this = brain;
}
Brain::~Brain(void)
{
}
Brain	&Brain::operator=(const Brain &brain)
{
	int	i;

	i = -1;
	while (++i < 100)
		ideas[i] = brain.ideas[i];
	return (*this);
}
