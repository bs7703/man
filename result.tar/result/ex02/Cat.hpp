/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cat.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:42:16 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/04 06:20:29 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CAT_HPP

# define CAT_HPP

#include <iostream>
#include "Animal.hpp"
#include "Brain.hpp"
class Cat: public Animal
{
	public:
	Cat(void);
	~Cat(void);
	Cat(const Cat &cat);
	Cat	&operator=(const Cat &cat);
	std::string	getType(void);
	void		makeSound(void) const;
	private:
	Brain		*brain;
};

#endif
