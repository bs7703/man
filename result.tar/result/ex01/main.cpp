/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:53:18 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/03 21:25:53 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"
#include <iostream>

int	main(void)
{
	Fixed		a;
	Fixed const	b(10);
	Fixed const	c(42.42f);
	Fixed const	d(b);

	a = Fixed(1234.4321f);
	std::cout << "a is" << a << std::endl;
	std::cout << "b is" << b << std::endl;
	std::cout << "c is" << c << std::endl;
	std::cout << "d is" << d << std::endl;
	std::cout << "a is as int" << a.toInt() << std::endl;
	std::cout << "b is as int" << b.toInt() << std::endl;
	std::cout << "c is as int" << c.toInt() << std::endl;
	std::cout << "d is as int" << d.toInt() << std::endl;
	return 0;
}
