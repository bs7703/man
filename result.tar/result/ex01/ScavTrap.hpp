/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:55:10 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 14:13:46 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SCAVTRAP_HPP

# define SCAVTRAP_HPP

#include "ClapTrap.hpp"

class ScavTrap : public ClapTrap
{
	public:
	~ScavTrap(void);
	ScavTrap(std::string name);
	ScavTrap(const ScavTrap &s);
	ScavTrap	&operator=(const ScavTrap &s);
	void	guardGate(void);
};

#endif
