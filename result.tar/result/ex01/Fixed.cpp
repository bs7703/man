/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:41:19 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 06:57:24 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed(int raw)
{
	std::cout << "Int constructor called" << std::endl;
	setRawBits(raw);
}
Fixed::Fixed(float val)
{
	int	n;

	std::cout << "Float constructor called" << std::endl;
	setRawBits((int)val);
	n = (int)roundf(val * 256) & 0xff;
	if (val < 0)
		rawbits -= n;
	else
		rawbits += n;
}
Fixed::Fixed(void)
{
	rawbits = 0;
	std::cout << "Default constructor called" << std::endl;
}
Fixed::Fixed(const Fixed &fix)
{
	std::cout << "Copy constructor called" << std::endl;
	*this = fix;
}
Fixed::~Fixed(void)
{
	std::cout << "Destructor called" << std::endl;
}
std::ostream&	operator<<(std::ostream& os, const Fixed &f)
{
	os << f.toFloat();
	return (os);
}
Fixed	&Fixed::operator=(const Fixed &fix)
{
	std::cout << "Assignation operator called" << std::endl;
	rawbits = fix.getRawBits();
	return (*this);
}
int				Fixed::getRawBits(void) const
{
	return (rawbits);
}
void		 	Fixed::setRawBits(int const raw)
{
	rawbits = (unsigned int)raw << FRACT_SIZE;
	if (raw < 0)
		rawbits |= 0x8fffff00;
}
float 	Fixed::toFloat(void) const
{
	float	n;

	n = ((unsigned int)(getRawBits() & 0xffffff00)) >> FRACT_SIZE;
	if (getRawBits() < 0)
	{
		n *= -1;
		n -= (float)(getRawBits() & 0xff) / (float)256;
	}
	else
		n += (float)(getRawBits() & 0xff) / (float)256;
	return (n);
}
int		Fixed::toInt(void) const
{
	int	i;

	i = (unsigned int)getRawBits() >> FRACT_SIZE;
	if (getRawBits() < 0)
		i *= -1;
	return (i);
}
