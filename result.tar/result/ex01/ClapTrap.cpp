/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ClapTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:22:00 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 16:36:26 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ClapTrap.hpp"

ClapTrap::ClapTrap(std::string n) : hp(10), ep(10), ap(0), name(n)
{
	std::cout << "name:" << name << std::endl;
	std::cout << "hp:" << hp << std::endl;
	std::cout << "ep:" << ep << std::endl;
	std::cout << "ap:" << ap << std::endl;
}
ClapTrap::ClapTrap(void)
{
	std::cout << "default clap has created.\n";
}
ClapTrap::ClapTrap(const ClapTrap &c)
{
	*this = c;
}
ClapTrap	&ClapTrap::operator=(const ClapTrap &c)
{
	name = c.getName();
	hp = c.getHp();
	ep = c.getEp();
	ap = c.getAp();
	return (*this);
}
ClapTrap::~ClapTrap(void)
{
	std::cout << "clap trap died\n";
}
void	ClapTrap::attack(std::string const & target)
{
	std::cout << "ClapTrap " << name <<  " attack " << target
		<< " causing " << ap << " points of damage!\n";
}
void	ClapTrap::takeDamage(unsigned int amount)
{
	if (amount > ep)
		ep = 0;
	else
		ep = (int)ep - (int)amount;
	std::cout << name << "has taken " << amount << " damages.\n";
	std::cout << "now " << name << " has only left " << ep << " of energy points.\n"; 
	std::cout << "maybe need a repair now.\n";
}
void	ClapTrap::beRepaired(unsigned int amount)
{
	if (ep + amount >= hp)
		ep = hp;
	else
		ep += amount;
	std::cout << name << " has repaired " << amount << " hps.\n";
	std::cout << "now " << name << "'s hp left " << ep << " much.\n"; 
}
unsigned int	ClapTrap::getHp(void) const
{
	return (hp);
}
unsigned int	ClapTrap::getEp(void) const
{
	return (ep);
}
unsigned int	ClapTrap::getAp(void) const
{
	return (ap);
}
std::string		ClapTrap::getName(void) const
{
	return (name);
}
