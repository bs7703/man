/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.hpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 07:57:07 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 16:12:58 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CURE_HPP

# define CURE_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"

class	Cure: public AMateria
{
	public:
	Cure(void);
	~Cure(void);
	Cure(const Cure &cure);
	std::string const	&getType(void) const;
	AMateria	*clone() const;
	Cure	&operator=(const Cure &ice);
	void		use(ICharacter&	target);
};

#endif
