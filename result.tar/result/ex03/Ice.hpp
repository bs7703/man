/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ice.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 07:57:07 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 16:07:51 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ICE_HPP

# define ICE_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"

class	Ice: public AMateria
{
	public:
	Ice(void);
	~Ice(void);
	Ice(const Ice &ice);
	std::string const	&getType(void) const;
	AMateria	*clone() const;
	Ice	&operator=(const Ice &ice);
	void		use(ICharacter&	target);
};

#endif
