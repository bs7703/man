/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 14:32:38 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:45:52 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "AMateria.hpp"

AMateria::AMateria(std::string const &t): type(t)
{
	shout = "";
}
AMateria::~AMateria(void)
{
}
std::string const	&AMateria::getType() const
{
	return (type);
}
