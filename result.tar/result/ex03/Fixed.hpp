/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:30:05 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/04 00:49:54 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_HPP

# define FIXED_HPP

#include <iostream>
#include <cmath>

class Fixed
{
	public:
	Fixed(void);
	Fixed(int val);
	Fixed(float val);
	Fixed(const Fixed &fix);
	~Fixed(void);
	void	operator=(const Fixed &fix);
	bool	operator>(const Fixed &fix);
	bool	operator<(const Fixed &fix);
	bool	operator<=(const Fixed &fix);
	bool	operator>=(const Fixed &fix);
	bool	operator==(const Fixed &fix);
	bool	operator!=(const Fixed &fix);
	Fixed	operator*(const Fixed &fix);
	Fixed	operator-(const Fixed &fix);
	Fixed	operator+(const Fixed &fix);
	Fixed	operator/(const Fixed &fix);
	Fixed	&operator--(void);
	Fixed	operator--(int);
	Fixed	&operator++(void);
	Fixed	operator++(int);
	int		getRawBits(void) const;
	void 	setRawBits(int const raw);
	float 	toFloat(void) const;
	int		toInt(void) const;
	static const Fixed	&min(const Fixed &fix1, const Fixed &fix2);
	static const Fixed	&max(const Fixed &fix1, const Fixed &fix2);
	private:
	static const int	FRACT_SIZE = 8;
	int					rawbits;
};
std::ostream&	operator<<(std::ostream& os, const Fixed &f);
#endif
