/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   AMateria.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 11:30:48 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:43:38 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef AMATERIA_HPP

#define AMATERIA_HPP

#include <iostream>
class ICharacter;

class	AMateria
{
	protected:
	const std::string	type;
	std::string 		shout;
	public:
	AMateria(std::string const &t);
	virtual ~AMateria(void);
	std::string const	&getType() const;
	virtual	AMateria	*clone() const = 0;
	virtual void		use(ICharacter& target) = 0;
};

#endif
