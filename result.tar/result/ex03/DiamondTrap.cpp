/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   DiamondTrap.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:58:13 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 14:56:50 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "DiamondTrap.hpp"

DiamondTrap::~DiamondTrap(void)
{
	std::cout << "DiamondTrap has died.\n";
}
DiamondTrap::DiamondTrap(const DiamondTrap &d):ScavTrap(d.name), FragTrap(d.name)
{
	*this = d;
}
DiamondTrap	&DiamondTrap::operator=(const DiamondTrap &d)
{
	ClapTrap::name = d.getName();
	name = d.getTrapName();
	ap = d.getAp();
	ep = d.getEp();
	hp = d.getHp();
	return (*this);
}
DiamondTrap::DiamondTrap(std::string n):ScavTrap(n), FragTrap(n)
{
	name = n;
	ClapTrap::name = n + " diamond_trap";
	ep = 50;
	std::cout << "name:" << name << std::endl;
	std::cout << "hp:" << hp << std::endl;
	std::cout << "ep:" << ep << std::endl;
	std::cout << "ap:" << ap << std::endl;
}
std::string	DiamondTrap::getTrapName(void) const
{
	return (name);
}
void	DiamondTrap::whoAMI(void)
{
	std::cout << ClapTrap::name << std::endl;
}
