/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ScavTrap.cpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:58:13 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 16:32:04 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ScavTrap.hpp"

ScavTrap::~ScavTrap(void)
{
	std::cout << "ScavTrap has died.\n";
}

ScavTrap::ScavTrap(const ScavTrap &s):ClapTrap(s.getName())
{
	*this = s;
}
ScavTrap	&ScavTrap::operator=(const ScavTrap &s)
{
	name = s.getName();
	this->hp = s.getHp();
	this->ep = s.getEp();
	this->ap = s.getAp();
	return (*this);
}
ScavTrap::ScavTrap(std::string n): ClapTrap(n)
{
	this->name = n;
	this->hp = 100;
	this->ep = 50;
	this->ap = 20;
	std::cout << "name:" << name << std::endl;
	std::cout << "hp:" << hp << std::endl;
	std::cout << "ep:" << ep << std::endl;
	std::cout << "ap:" << ap << std::endl;
}

void	ScavTrap::guardGate(void)
{
	std::cout << "ScavTrap has enterd a guard mode.\n";
}
