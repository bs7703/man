/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Ice.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 03:43:57 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:45:20 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Ice.hpp"

Ice::Ice(void): AMateria("ice")
{
	shout = "* shoots an ice bolt at ";
}
Ice::~Ice(void)
{
}
AMateria	*Ice::clone() const
{
	return (new Ice());
}
Ice::Ice(const Ice	&ice): AMateria("ice")
{
	*this = ice;
}
Ice	&Ice::operator=(const Ice &ice)
{
	shout = ice.shout;
	return (*this);
}
void		Ice::use(ICharacter& target)
{
	std::cout << shout << target.getName() << " *\n";
}
