/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   DiamondTrap.hpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:55:10 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 14:53:20 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DIAMONDTRAP_HPP

# define DIAMONDTRAP_HPP

#include "ScavTrap.hpp"
#include "FragTrap.hpp"

class DiamondTrap : public ScavTrap, public FragTrap
{
	public:
	~DiamondTrap(void);
	DiamondTrap(void);
	DiamondTrap(const DiamondTrap &d);
	DiamondTrap(std::string name);
	DiamondTrap	&operator=(const DiamondTrap &d);
	std::string	getTrapName(void) const;
	void	whoAMI(void);
	using	ScavTrap::attack;
	private:
	std::string	name;
	using	FragTrap::hp;
	using	ScavTrap::ep;
	using	FragTrap::ap;
};

#endif
