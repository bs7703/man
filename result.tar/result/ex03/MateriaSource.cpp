/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   MateriaSource.cpp                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 05:19:43 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:26:31 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "MateriaSource.hpp"

MateriaSource::~MateriaSource(void)
{
	int	i;

	i = -1;
	while (++i < 4)
		if (inventory[i])
			delete inventory[i];
}
MateriaSource::MateriaSource(const MateriaSource &m)
{
	int	i;

	idx = m.idx;
	i = -1;
	while (++i < 4)
	{
		if (inventory[i])
			delete	inventory[i];
		inventory[i] = m.inventory[i];
	}
}
MateriaSource	&MateriaSource::operator=(const MateriaSource &m)
{
	int	i;

	idx = m.idx;
	i = -1;
	while (++i < 4)
	{
		if (inventory[i])
			delete	inventory[i];
		inventory[i] = m.inventory[i];
	}
	return (*this);
}
MateriaSource::MateriaSource(void)
{
	int	i;

	i = -1;
	idx = 0;
	while (++i < 4)
		inventory[i] = 0;
}
void		MateriaSource::learnMateria(AMateria* am)
{
	if (idx > 3)
	{
		std::cout << "Cant learn more sources.\n";
		return ;
	}
	inventory[idx++] = am->clone();
}
AMateria*	MateriaSource::createMateria(std::string const &type)
{
	int			i;

	i = -1;
	while (++i < idx)
	{
		if (type.compare(inventory[i]->getType()) == 0)
		{
			return (inventory[i]->clone());
		}
	}
	return (0);
}
