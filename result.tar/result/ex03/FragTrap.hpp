/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   FragTrap.hpp                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 02:55:10 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 14:27:59 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FRAGTRAP_HPP

# define FRAGTRAP_HPP

#include "ClapTrap.hpp"

class FragTrap : virtual public ClapTrap
{
	public:
	~FragTrap(void);
	FragTrap(std::string name);
	FragTrap(const FragTrap &s);
	FragTrap	&operator=(const FragTrap &s);
	void	highFiveGuys(void);
};

#endif
