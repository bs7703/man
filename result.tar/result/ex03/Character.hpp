/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.hpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 03:45:04 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 05:54:00 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHARACTER_HPP

# define CHARACTER_HPP

#include "AMateria.hpp"
#include "ICharacter.hpp"
#include <iostream>

class	Character: public ICharacter
{
	public:
	~Character(void);
	Character(std::string name);
	Character(Character	const &c);
	Character	&operator=(Character const &c);
	std::string	const &getName() const;
	void	equip(AMateria* m);
	void	unequip(int idx);
	void	use(int idx, ICharacter& target);
	private:
	AMateria	*inventory[4];
	int			idx;
	std::string	name;
};

#endif
