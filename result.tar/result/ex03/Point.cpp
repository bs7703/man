/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Point.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 23:37:00 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/04 02:37:39 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Point.hpp"

Point::Point(void) : x(Fixed(0)), y(Fixed(0))
{
}
Point::Point(const float a, const float b) : x(Fixed(a)), y(Fixed(b))
{
}
Point::~Point(void)
{
}
Point::Point(Point &point) : x(Fixed(point.x)), y(Fixed(point.y))
{
}
int	Point::whichside(const Point &x, const Point &y) const
{
	float	r;

	r = (x.getY().toFloat() - y.getY().toFloat()) / (x.getX().toFloat() - y.getX().toFloat());
	r = r * (getX().toFloat() - x.getX().toFloat());
	if (r < getY().toFloat())
		return (1);
	else if (r == getY().toFloat())
		return (0);
	return (-1);
}
/*Point	&Point::operator=(const Point& point)
{
	return (*this);
}*/
Fixed	Point::getX(void) const
{
	return (x);
}
Fixed	Point::getY(void) const
{
	return (y);
}
