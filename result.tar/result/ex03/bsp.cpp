/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsp.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 23:37:12 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/04 02:38:23 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Point.hpp"

bool	bsp(Point const x, Point const y, Point const z, Point const judge)
{
	if ((x.whichside(y, z) == judge.whichside(y, z)) + 
		(y.whichside(x, z) ==  judge.whichside(x, z)) +
		(z.whichside(x, y) ==  judge.whichside(x, y)) == 3)
		return (true);
	return (false);
}
