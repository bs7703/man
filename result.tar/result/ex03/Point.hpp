/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Point.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 23:37:04 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/04 02:07:24 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef POINT_HPP

# define POINT_HPP

#include "Fixed.hpp"

class Point
{
	public:
	Point(void);
	~Point(void);
	Point(Point &point);
	int	whichside(const Point &x, const Point &y) const;
	Point(const float a, const float b);
	Point	&operator=(const Point& point);
	Fixed	getX(void) const;
	Fixed	getY(void) const;
	private:
	Fixed const	x;
	Fixed const	y;
};
bool	bsp(Point const x, Point const y, Point const z, Point const judge);
#endif
