/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cure.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 03:43:57 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:47:01 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Cure.hpp"

Cure::Cure(void): AMateria("cure")
{
	shout = "* heals ";
}
Cure::~Cure(void)
{
}
AMateria	*Cure::clone() const
{
	return (new Cure());
}
Cure::Cure(const Cure	&cure): AMateria("cure")
{
	*this = cure;
}
Cure	&Cure::operator=(const Cure &cure)
{
	shout = cure.shout;
	return (*this);
}
void		Cure::use(ICharacter& target)
{
	std::cout << shout << target.getName() << "’s wounds *\n";
}
