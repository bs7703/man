/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Character.cpp                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/05 03:44:39 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:34:27 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Character.hpp"

Character::~Character(void)
{
	int	i;

	i = -1;
	while (++i < 4)
	{
		if (inventory[i])
			delete	inventory[i];
	}
};
Character::Character(std::string name)
{
	this->name = name;
	idx = 0;
}
Character::Character(Character	const &c)
{
	int	i;

	name = c.name;
	idx = c.idx;
	i = -1;
	while (++i < 4)
		inventory[i] = c.inventory[i]->clone();
}
Character	&Character::operator=(Character const &c)
{
	int	i;

	name = c.name;
	idx = c.idx;
	i = -1;
	while (++i < 4)
	{
		if (inventory[i])
			delete	inventory[i];
		inventory[i] = c.inventory[i]->clone();
	}
	return (*this);
}
std::string	const &Character::getName() const
{
	return (name);
}
void	Character::equip(AMateria* m)
{
	int	i;

	i = -1;
	if (idx >= 4)
		std::cout << "inventory is FULL\n";
	while (++i < 4)
	{
		if (inventory[i] == 0)
		{
			inventory[i] = m;
			break;
		}
	}
	++idx;
}
void	Character::unequip(int idx)
{
	if (this->idx == 0)
	{
		std::cout << "already all empty.\n";
		return ;
	}
	else if (idx > 3 || idx < 0)
	{
		std::cout << "index range wrong\n";
		return ;
	}
	else if (inventory[idx] == 0)
	{
		std::cout << "slot is empty can`t unequip.\n";
		return ;
	}
	inventory[idx] = 0;
	--(this->idx);
}
void	Character::use(int idx, ICharacter& target)
{
	if (idx > 3 ||  idx < 0 || inventory[idx] == 0)
	{
		if (idx > 3 || idx < 0)
			std::cout << "index range wrong\n";
		else
			std::cout << "slot empty\n";
		return ;
	}
	inventory[idx]->use(target);
}
