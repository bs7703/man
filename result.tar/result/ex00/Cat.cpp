/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Cat.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:45:58 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 09:57:52 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Cat.hpp"

Cat::Cat(void)
{
	Cat::type = "cat";
}
Cat::~Cat(void)
{
}
Cat::Cat(const Cat &cat)
{
	type = cat.type;
}
Cat	&Cat::operator=(const Cat &cat)
{
	type = cat.type;
	return (*this);
}
std::string	Cat::getType(void)
{
	return (type);
}
void	Cat::makeSound(void) const
{
	std::cout << "meowmeow\n";
}
