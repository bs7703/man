/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.cpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:41:19 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 07:00:03 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Fixed.hpp"

Fixed::Fixed(int raw)
{
	setRawBits(raw);
}
Fixed::Fixed(void)
{
	rawbits = 0;
	std::cout << "Default constructor called" << std::endl;
}
Fixed::Fixed(const Fixed &fix)
{
	std::cout << "Copy constructor called" << std::endl;
	rawbits = fix.getRawBits();
}
Fixed::~Fixed(void)
{
	std::cout << "Destructor called" << std::endl;
}
Fixed	&Fixed::operator=(const Fixed &fix)
{
	std::cout << "Assignation operator called" << std::endl;
	rawbits = fix.getRawBits();
	return (*this);
}
int				Fixed::getRawBits(void) const
{
	std::cout << "getRawBits member function called" << std::endl;
	return (rawbits);
}
void		 	Fixed::setRawBits(int const raw)
{
	rawbits = (unsigned int)raw << FRACT_SIZE;
	if (raw < 0)
		rawbits |= 0x8fffff00;
}
