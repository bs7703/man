/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Animal.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:42:16 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:59:10 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ANIMAL_HPP

# define ANIMAL_HPP

#include <iostream>

class Animal
{
	public:
	Animal(void);
	virtual	~Animal(void);
	Animal(const Animal &animal);
	Animal	&operator=(const Animal &animal);
	std::string	getType(void) const;
	virtual void	makeSound(void) const;
	protected:
	std::string	type;
};

#endif
