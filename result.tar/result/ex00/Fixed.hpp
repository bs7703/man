/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Fixed.hpp                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/03 16:30:05 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 06:55:35 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FIXED_HPP

# define FIXED_HPP

#include <iostream>

class Fixed
{
	public:
	Fixed(void);
	Fixed(int val);
	Fixed(const Fixed &fix);
	~Fixed(void);
	Fixed	&operator=(const Fixed &fix);
	int		getRawBits(void) const;
	void 	setRawBits(int const raw);
	private:
	static const int	FRACT_SIZE = 8;
	int					rawbits;
};
#endif
