/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dog.cpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:45:58 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 19:56:11 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Dog.hpp"

Dog::Dog(void)
{
	Dog::type = "dog";
}

Dog::~Dog(void)
{
}
Dog::Dog(const Dog &dog)
{
	type = dog.type;
}
Dog	&Dog::operator=(const Dog &dog)
{
	type = dog.type;
	return (*this);
}
std::string	Dog::getType(void)
{
	return (type);
}
void	Dog::makeSound(void) const
{
	std::cout << "walwal\n";
}
