/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dog.hpp                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/04 05:42:16 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/06 09:56:12 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DOG_HPP

# define DOG_HPP

#include <iostream>
#include "Animal.hpp"

class Dog: public Animal
{
	public:
	Dog(void);
	~Dog(void);
	Dog(const Dog &dog);
	Dog	&operator=(const Dog &dog);
	std::string	getType(void);
	void		makeSound(void) const;
};

#endif
