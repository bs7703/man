/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 09:39:06 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 09:46:11 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

int	main(void)
{
	Zombie	z;
	Zombie	*l;

	z.announce();
	l = z.newZombie("myname");
	l->announce();
	delete l;
	z.randomChump("break");
}
