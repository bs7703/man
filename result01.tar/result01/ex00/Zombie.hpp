/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 09:18:21 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 09:48:08 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP

# define ZOMBIE_HPP

#include <iostream>

class Zombie
{
	public:
	Zombie(std::string name);
	Zombie(void);
	void	announce(void);
	Zombie	*newZombie(std::string name);
	void	randomChump(std::string name);
	~Zombie(void);
	private:
	std::string	name;
};

#endif
