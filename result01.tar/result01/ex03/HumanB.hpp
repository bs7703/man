/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   HumanB.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 11:08:08 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 12:54:42 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef HUMANB_HPP

# define HUMANB_HPP

#include <iostream>
#include "Weapon.hpp"

class HumanB
{
	public:
	Weapon*		weapon;
	std::string	name;
	void	attack(void);
	void	setWeapon(Weapon &weapon);
	~HumanB(void);
	HumanB(std::string name);
};

#endif
