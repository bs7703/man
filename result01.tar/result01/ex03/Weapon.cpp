/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Weapon.cpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 11:07:53 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 13:12:17 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"

Weapon::Weapon(std::string type)
{
	this->type = type;
}
Weapon::~Weapon(void)
{
}
std::string Weapon::getType(void)
{
	return (type);
}
void	Weapon::setType(std::string type)
{
	this->type = type;
}
