/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 12:59:54 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 12:54:35 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Weapon.hpp"
#include "HumanA.hpp"
#include "HumanB.hpp"

int	main(void)
{
	{
		Weapon club = Weapon("crude spike club");

		HumanA bob("Bob", club);
		bob.attack();
		club.setType("some weapon");
		bob.attack();
	}
	{
		Weapon club = Weapon("crude spike club");

		HumanB jim("Jim");
		jim.setWeapon(club);
		jim.attack();
		club.setType("some weapon");
		jim.attack();
	}
}
