/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 11:13:26 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/05 12:58:33 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <iostream>
#include <fstream>

void	replaceAll(std::string&	input, std::string s1, std::string s2)
{
	std::string	ex;
	std::string	tofind;
	int	last;

	last = 0;
	while ((last = input.find(s1, last)) != -1)
	{
		input.erase(last, s1.length());
		input.insert(last, s2);
		last += s2.length();
	}
}

int	main(int n, char **args)
{
	std::ifstream	ifs;
	std::ofstream	ofs;
	std::string		one;
	std::string		main;
	std::string		s1;
	std::string		s2;
	char			c;

	if (n <= 3)
		return (0);
	one = args[1];
	s1 = args[2];
	s2 = args[3];
	if (one.length() == 0 || s1.length() == 0 || s2.length() == 0)
		return (0);
	ifs.open(one);
	ofs.open(one + ".replace");
	if (ifs.fail() || ofs.fail())
	{
		std::cerr << "file name error try again" << std::endl;
		return (0);
	}
	while (ifs.get(c))
		main.push_back(c);
	replaceAll(main, s1, s2);
	ofs << main;
	ofs.close();
	ifs.close();
}
