/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ZombieHorde.cpp                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 09:56:53 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 10:33:50 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Zombie.hpp"

Zombie* Zombie::zombieHorde(int N, std::string name)
{
	Zombie	*z;
	int		i;

	i = -1;
	if (N <= 0)
		return (0);
	z = new Zombie[N];
	while (++i < N)
		z[i].setter(name);
	return (z);
}

