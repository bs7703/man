/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Zombie.hpp                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 09:18:21 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 10:33:12 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ZOMBIE_HPP

# define ZOMBIE_HPP

#include <iostream>

class Zombie
{
	public:
	Zombie(std::string name);
	Zombie(void);
	void	announce(void);
	void	setter(std::string name);
	Zombie	*newZombie(std::string name);
	void	randomChump(std::string name);
	Zombie* zombieHorde(int N, std::string name);
	~Zombie(void);
	private:
	std::string	name;
};

#endif
