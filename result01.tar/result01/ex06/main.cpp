/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gimsang-won <marvin@42.fr>                 +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/02 15:41:01 by gimsang-w         #+#    #+#             */
/*   Updated: 2022/03/02 17:55:01 by gimsang-w        ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Karen.hpp"

int	main(int n, char **args)
{
	std::string	s;
	Karen		k;
	int			i;

	if (n <= 1)
		return (0);
	s = args[1];
	if (s.compare("ERROR") == 0)
		i = 0;
	else if (s.compare("WARNING") == 0)
		i = 1;
	else if (s.compare("INFO") == 0)
		i = 2;
	else if (s.compare("DEBUG") == 0)
		i = 3;
	else
		i = 4;
	switch (i)
	{
		case	3:
						k.complain("DEBUG");
						std::cout << "\n";
		case	2:
						k.complain("INFO");
						std::cout << "\n";
		case	1:
						k.complain("WARNING");
						std::cout << "\n";
		case	0:
						k.complain("ERROR");
						break ;
		default:
						std::cout << "[ Probably complaining about insignificant problems ]" << std::endl;
						break ;
	}
}
